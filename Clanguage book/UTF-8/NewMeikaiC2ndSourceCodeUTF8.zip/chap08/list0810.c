﻿// EOFの値と数字文字の値を表示

#include <stdio.h>

int main(void)
{
	printf("EOF ＝ %d\n", EOF);
	printf("'0' ＝ %d\n", '0');
	printf("'1' ＝ %d\n", '1');
	printf("'2' ＝ %d\n", '2');
	printf("'3' ＝ %d\n", '3');
	printf("'4' ＝ %d\n", '4');
	printf("'5' ＝ %d\n", '5');
	printf("'6' ＝ %d\n", '6');
	printf("'7' ＝ %d\n", '7');
	printf("'8' ＝ %d\n", '8');
	printf("'9' ＝ %d\n", '9');

	return 0;
}
