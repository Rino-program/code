﻿// printf関数とputs関数で%を表示

#include <stdio.h>

int main(void)
{
	puts("%");			// １個の%を表示して改行
	printf("%%\n");		// １個の%を表示して改行

	return 0;
}
