﻿// 挨拶と自己紹介（別の行に表示・その２）

#include <stdio.h>

int main(void)
{
	printf("こんにちは。\n");						// 最後に改行
	printf("私の名前は福岡太郎です。\n");			// 最後に改行

	return 0;
}
