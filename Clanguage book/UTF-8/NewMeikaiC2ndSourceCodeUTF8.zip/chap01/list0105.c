﻿// 挨拶と自己紹介（別の行に表示・その１）

#include <stdio.h>

int main(void)
{
	printf("こんにちは。\n私の名前は福岡太郎です。\n");	// 途中と最後で改行

	return 0;
}
