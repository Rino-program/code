﻿// 整数値15から37を減じた結果を表示

#include <stdio.h>

int main(void)
{
	printf("%d", 15 - 37);		// 整数値15から37を減じた結果を10進数で表示

	return 0;
}
