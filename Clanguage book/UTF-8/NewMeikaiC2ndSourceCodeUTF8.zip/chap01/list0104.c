﻿// 挨拶と自己紹介

#include <stdio.h>

int main(void)
{
	printf("こんにちは。私の名前は福岡太郎です。\n");	// 最後に改行

	return 0;
}
