﻿// 整数値15と37を加えた結果を丁寧に表示

#include <stdio.h>

int main(void)
{
	printf("15と37の和は%dです。\n", 15 + 37);		// 表示後に改行

	return 0;
}
