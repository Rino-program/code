﻿/* 整数値15と37を加えた結果を表示 */

#include <stdio.h>

int main(void)
{
	printf("%d", 15 + 37);		// 整数値15と37を加えた結果を10進数で表示

	return 0;
}
