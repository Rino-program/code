﻿// 二つの変数に値を代入せずに表示

#include <stdio.h>

int main(void)
{
	int x, y;							// xとyはint型の変数

	printf("xの値は%dです。\n", x);		// xの値を表示
	printf("yの値は%dです。\n", y);		// yの値を表示

	return 0;
}
