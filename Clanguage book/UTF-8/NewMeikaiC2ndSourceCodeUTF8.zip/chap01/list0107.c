﻿// 挨拶して警報を３回発する

#include <stdio.h>

int main(void)
{
	printf("こんにちは。\a\a\a\n");		// 表示とともに警報を３回発する

	return 0;
}
